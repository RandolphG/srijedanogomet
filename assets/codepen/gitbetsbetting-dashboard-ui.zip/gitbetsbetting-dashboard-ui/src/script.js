new Vue({
  el: "#app",
  data: {
    leftBarOpened: false,
    betOpened: true
  }
});
